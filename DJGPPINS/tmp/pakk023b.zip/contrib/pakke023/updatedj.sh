# $Id: updatedj.sh,v 1.3 2002/06/23 20:28:30 richdawe Exp $
cp -vR share/pakke/* $DJDIR/share/pakke/
