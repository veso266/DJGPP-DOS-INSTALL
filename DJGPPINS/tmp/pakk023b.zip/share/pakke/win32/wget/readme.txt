Wget Binaries for Win32
~~~~~~~~~~~~~~~~~~~~~~~

The version of wget used is 1.8.1. The sources for wget 1.8.1
can be found in the wget/ directory off the pakke source distribution's
top-level directory.

The wget binaries for Win32 were obtained from:

    http://space.tin.it/computer/hherold/

The wget home page is:

    http://sunsite.dk/wget

Richard Dawe <rich@phekda.freeserve.co.uk> 2002-06-23
